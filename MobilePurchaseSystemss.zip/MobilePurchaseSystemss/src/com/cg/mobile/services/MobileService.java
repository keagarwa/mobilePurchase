package com.cg.mobile.services;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobile;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.exceptions.InvalidCustomerNameException;
import com.cg.mobile.exceptions.InvalidMailIdException;
import com.cg.mobile.exceptions.InvalidMobileIdException;
import com.cg.mobile.exceptions.InvalidPhoneNumberException;
import com.cg.mobile.exceptions.InvalidQuantityException;
import com.cg.mobile.exceptions.MobileDetailsNotFound;
import com.cg.mobile.exceptions.PurchaseServicesDownException;

public interface MobileService {
 int addPurchaseDetails(String customerName,String mailId,String phoneNo,int mobileId)
			throws SQLException, PurchaseServicesDownException, InvalidQuantityException, InvalidMailIdException, InvalidCustomerNameException, InvalidPhoneNumberException, InvalidMobileIdException;
 ArrayList<Mobile> findAllMobile() throws SQLException, PurchaseServicesDownException;
 boolean deleteOne(int mobileId) throws PurchaseServicesDownException;
 ArrayList<Mobile> findBetweenRange(int startingPrice,int endingPrice) throws PurchaseServicesDownException;
}
