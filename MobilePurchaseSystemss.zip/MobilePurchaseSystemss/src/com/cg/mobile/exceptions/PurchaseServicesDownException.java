package com.cg.mobile.exceptions;

public class PurchaseServicesDownException extends Exception {

	public PurchaseServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PurchaseServicesDownException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PurchaseServicesDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PurchaseServicesDownException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PurchaseServicesDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
