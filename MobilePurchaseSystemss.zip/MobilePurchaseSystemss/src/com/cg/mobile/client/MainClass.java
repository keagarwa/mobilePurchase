package com.cg.mobile.client;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobile.beans.Mobile;
import com.cg.mobile.exceptions.InvalidCustomerNameException;
import com.cg.mobile.exceptions.InvalidMailIdException;
import com.cg.mobile.exceptions.InvalidMobileIdException;
import com.cg.mobile.exceptions.InvalidPhoneNumberException;
import com.cg.mobile.exceptions.InvalidQuantityException;
import com.cg.mobile.exceptions.MobileDetailsNotFound;
import com.cg.mobile.exceptions.PurchaseServicesDownException;
import com.cg.mobile.services.MobileService;
import com.cg.mobile.services.MobileServiceImpl;
import com.cg.mobile.util.ConnectionProvider;
public class MainClass {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws SQLException, PurchaseServicesDownException, InvalidQuantityException, MobileDetailsNotFound, InvalidMailIdException, InvalidCustomerNameException, InvalidPhoneNumberException, InvalidMobileIdException {
		MobileService mobileService=new MobileServiceImpl();
		Scanner  sc=new Scanner(System.in);
		String s="yes";
		Connection con=ConnectionProvider.getDBConnection();
		if(con!=null)
			System.out.println("coooon");
		do{
			System.out.println("1.Enter Customer's purchase Details");
			System.out.println("2.Exit");
			System.out.println("Enter your Choice");
			int choice=sc.nextInt();
			switch(choice){
			case 1:
				System.out.println("Enter the name of the customer");
				String customerName=sc.next();
				System.out.println("Enter the mailId of customer");
				String mailId=sc.next();
				System.out.println("Enter customer phone number");
				String phoneNo=sc.next();
				System.out.println("Enter MobileId of mobile purchased");
				int mobileId=sc.nextInt(); 
				int purchaseId=mobileService.addPurchaseDetails(customerName, mailId, phoneNo, mobileId);
				System.out.println(purchaseId);
				ArrayList<Mobile> list=mobileService.findAllMobile();
				for (Mobile mobile : list) {
					System.out.println(mobile);
				}
				ArrayList<Mobile> list1=mobileService.findBetweenRange(5000, 10000);
				for (Mobile mobile : list1) {
					System.out.println(mobile);
				}
				mobileService.deleteOne(1001);
				break;
			default:
				System.out.println("Invalid data Entered");
				System.out.println("Do you want to continue(Y/N)");
				s=sc.next();
			}
		}while(s.startsWith("Y")||s.startsWith("y"));
	}

}