package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mobile.beans.Mobile;
import com.cg.mobile.beans.PurchaseDetails;
import com.cg.mobile.exceptions.InvalidMobileIdException;
import com.cg.mobile.exceptions.InvalidQuantityException;
import com.cg.mobile.util.ConnectionProvider;

public class MobileDAOImpl implements MobileDAO{
	private Connection conn=ConnectionProvider.getDBConnection();

	@Override
	public int save(PurchaseDetails purchaseDetails)
			throws SQLException, InvalidQuantityException {
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt3=conn.prepareStatement("select quantity from mobiles where mobileid="+purchaseDetails.getMobile().getMobileId());
			ResultSet rs1 = pstmt3.executeQuery();
			rs1.next();
			int x=rs1.getInt(1);
			/*System.out.println(x);*/
			if(x>0){
				// sysdate hmesa last m rhna hoga warna error aaega
			PreparedStatement pstmt1 = conn.prepareStatement("insert into purchasedetails(cname,mailid,phoneno,mobileid,purchasedate) values (?,?,?,?,sysdate)");
			pstmt1.setString(1, purchaseDetails.getCustomerName());
			pstmt1.setString(2, purchaseDetails.getMailId());
			pstmt1.setString(3, purchaseDetails.getPhoneNo());
			pstmt1.setInt(4, purchaseDetails.getMobile().getMobileId());
			pstmt1.executeUpdate();
			
			//set tansaction_id in format of table
			
			PreparedStatement pstmt2 = conn.prepareStatement("select max(purchaseid) from purchasedetails");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int purchaseid= rs.getInt(1);
			conn.commit();
			return purchaseid;
			}
			else
				throw new InvalidQuantityException("Error Message");
			}catch(SQLException e){
				e.printStackTrace();
				conn.rollback();
				throw e;
			}
			finally{
				conn.setAutoCommit(true);
			}
		}

	@Override
	public ArrayList<Mobile> findAllMobile() throws SQLException {
			ArrayList<Mobile> list=new ArrayList<>();
			PreparedStatement pstmt=conn.prepareStatement("select * from mobiles");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				int mobileid=rs.getInt("mobileid");
				String name=rs.getString("name");
				int price=rs.getInt("price");
				String quantity=rs.getString("quantity");
				Mobile mobile=new Mobile(mobileid, name, price, quantity);
				list.add(mobile);
			}
				return list;
	}



	@Override
	public boolean deleteOne(int mobileId) throws InvalidMobileIdException {
		try {
			PreparedStatement pstmt1=conn.prepareStatement("SELECT  * from MOBILES where mobileid= "+mobileId);
			ResultSet rs1=pstmt1.executeQuery();
			boolean flag=rs1.next();
			if(flag==false)
				throw new InvalidMobileIdException();
			
			PreparedStatement pstmt2=conn.prepareStatement("DELETE from mobiles where mobileid="+mobileId);
			pstmt2.executeUpdate();
			return true;
		} catch (SQLException e) {
			throw new InvalidMobileIdException();
		}
	}

	@Override
	public ArrayList<Mobile> findBetweenRange(int startingPrice, int endingPrice) throws SQLException {
		
		PreparedStatement pstmt=conn.prepareStatement("select * from mobiles where price between "+startingPrice+ " and "+endingPrice);
		ResultSet rs=pstmt.executeQuery();
		ArrayList<Mobile> list=new ArrayList<>();
		while(rs.next()){
			
			int mobileid=rs.getInt("mobileid");
			String name=rs.getString("name");
			int price=rs.getInt("price");
			String quantity=rs.getString("quantity");
			Mobile mobile=new Mobile(mobileid, name, price, quantity);
			list.add(mobile);
		}
		
		return list;
	}

}
